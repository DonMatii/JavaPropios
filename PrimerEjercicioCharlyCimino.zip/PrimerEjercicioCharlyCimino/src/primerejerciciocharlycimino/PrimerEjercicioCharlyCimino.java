/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package primerejerciciocharlycimino;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class PrimerEjercicioCharlyCimino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        int anioDeNacimiento, anioActual, edadDelUsuario;

        System.out.println("Hola! En qu� a�o naciste? pone solamente el a�o: ");

        anioDeNacimiento = Integer.parseInt(sc.nextLine());

        System.out.println("Oye, y en qu� a�o estamos actualmente?");
        anioActual = Integer.parseInt(sc.nextLine());

        edadDelUsuario = anioActual - anioDeNacimiento;

        System.out.println("Asi que tienes: " + edadDelUsuario + " a�os... O quiz� " + (edadDelUsuario-1) + " a�os (Si es que a�n no los cumples por tu mes de nacimiento... Jeje, bien!");
    }

}
