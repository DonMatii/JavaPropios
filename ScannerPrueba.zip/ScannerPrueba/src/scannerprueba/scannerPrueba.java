/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scannerprueba;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class scannerPrueba {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Hola! �Como te llamas? ");
        String nombre;
        nombre = sc.nextLine();

        System.out.println("\n Y �Qu� edad tienes? ");
        int edad;
        edad = sc.nextInt();

        System.out.println("\n Asi que te llamas: " + nombre + " ... Hola  " + nombre + " ! " + "Y tienes: " + edad + " a�os...");

        if (edad < 18) {
            System.out.println("Eres chiquitito... por que no fuiste al colegio?");
        } else if (edad > 18 && edad <= 33) {
            System.out.println("Esta bien, estas en la flor de la vida");
        } else {
            System.out.println("\n Ya tienes: " + edad + " o m�s a�os... est�s bien? voy llamando a la funeraria, abuelito?");
        }
    }
}
