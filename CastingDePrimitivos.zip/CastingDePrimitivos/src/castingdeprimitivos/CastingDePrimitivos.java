/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package castingdeprimitivos;

/**
 *
 * @author DonMatii
 */
public class CastingDePrimitivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int num1 = 6;
        double num2 = 3.12;
        
        double valorDouble = num1;
        int valorEntero = (int)num2;
        
        System.out.println("el valor va a pasar a double, mira: " + valorDouble);
        
        System.out.println("el valor va a pasar a entero, mira: " + valorEntero);
        
    }
    
}
