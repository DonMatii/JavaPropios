/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tercerejerciciocharlycimimo;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class TercerEjercicioCharlyCimimo {

//Ejercicio para ver cuantos billetes necesita de cada cantidad para llegar al dinero ingresado por el usuario
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        int monto, cantidadDeBilletesDe100, cantidadDeBilletesDe50, cantidadDeBilletesDe20, cantidadDeBilletesDe10, cantidadDeBilletesDe5, cantidadDeBilletesDe2;

        System.out.println("Ingresa un monto $: ");
        monto = Integer.parseInt(sc.nextLine());

        cantidadDeBilletesDe100 = monto / 100;
        monto = monto % 100; //lo que sobr� del billete que se ingrese

        cantidadDeBilletesDe50 = monto / 50;
        monto = monto % 50; //lo que sobr� del billete que se ingrese

        cantidadDeBilletesDe20 = monto / 20;
        monto = monto % 20; //lo que sobr� del billete que se ingrese

        cantidadDeBilletesDe10 = monto / 10;
        monto = monto % 10; //lo que sobr� del billete que se ingrese

        cantidadDeBilletesDe5 = monto / 5;
        monto = monto % 5; //lo que sobr� del billete que se ingrese

        cantidadDeBilletesDe2 = monto / 2;
        monto = monto % 2; //lo que sobr� del billete que se ingrese

        System.out.println("Cantidad de billetes de 100: " + cantidadDeBilletesDe100);
        System.out.println("Cantidad de billetes de 50: " + cantidadDeBilletesDe50);
        System.out.println("Cantidad de billetes de 20: " + cantidadDeBilletesDe20);
        System.out.println("Cantidad de billetes de 10: " + cantidadDeBilletesDe10);
        System.out.println("Cantidad de billetes de 5: " + cantidadDeBilletesDe5);
        System.out.println("Cantidad de billetes de 2: " + cantidadDeBilletesDe2);
        System.out.println("Cantidad de billetes de 1: " + monto);

    }

}
