/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package segundoejerciciocharlycimimo;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class SegundoEjercicioCharlyCimimo {

    final static int CANTIDAD_DE_PASADAS_DE_ALAMBRE = 3;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        int ancho, largo, superficieDelTerreno, perimetroDelTerreno, cantidadDeAlambre;
        double precioMetroCuadrado, valorDelTerreno;

        System.out.println("Ingresa el ancho del terreno: ");
        ancho = Integer.parseInt(sc.nextLine());

        System.out.println("Ingresa el largo del terreno");
        largo = Integer.parseInt(sc.nextLine());

        System.out.println("Ingresa el valor del metro cuadrado");
        precioMetroCuadrado = Integer.parseInt(sc.nextLine());

        superficieDelTerreno = ancho * largo;
        valorDelTerreno = superficieDelTerreno * precioMetroCuadrado;

        perimetroDelTerreno = (2 * ancho) + (2 * largo);
        cantidadDeAlambre = perimetroDelTerreno * CANTIDAD_DE_PASADAS_DE_ALAMBRE;

        System.out.println("El valor del terreno es de: $" + valorDelTerreno + " Dolares");
        System.out.println("La cantidad de alambre para " + CANTIDAD_DE_PASADAS_DE_ALAMBRE + " pasadas de alambre es de: " + cantidadDeAlambre + " metros");
    }

}
