/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package porcentajedealumnosaprobados;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class PorcentajeDeAlumnosAprobados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        System.out.println("Bienvenid@ profesor@, con este sstema ser� capaz de ver  el porcentaje real de los alumnos que aprobaron su asignatura.");

        Scanner sc = new Scanner(System.in);
        int totalDeAlumnos, alumnosAprobados;
        double porcentajeDeAlumnosAprobados, porcentajeDeAlumnosReprobados;

        System.out.println("Ingrese la cantidad total de alumnos en su curso: ");
        totalDeAlumnos = Integer.parseInt(sc.nextLine());

        System.out.println("Ingrese la cantidad de alumnos que aprobaron en su curso");
        alumnosAprobados = Integer.parseInt(sc.nextLine());

        porcentajeDeAlumnosAprobados = ((double) alumnosAprobados / totalDeAlumnos) * 100;
        porcentajeDeAlumnosReprobados = 100 - porcentajeDeAlumnosAprobados;

        System.out.println("El porcentaje de alumnos aprobados es de: " + porcentajeDeAlumnosAprobados + "%, y el porcentaje de alumnos reprobados es de: " + porcentajeDeAlumnosReprobados + "%");
    }

}
