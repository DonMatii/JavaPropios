/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package usandoconstantes;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class UsandoConstantes {
    
    //Constantes, VAN AFUERA DEL MAIN Y EN MAYUSCULAS
    final static double CANTIDAD_JORNADAS_TRABAJADAS = 5.5;
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Vamos a calcular el sueldo semanal de una persona
        
        Scanner sc = new Scanner(System.in);
        double sueldoDiario, sueldoSemanal;
        
        System.out.println("Ingresa por favor tu sueldo diario: ");
        sueldoDiario = Double.parseDouble(sc.nextLine());
        
        //TRABAJAA TODOS LOS DIAS HABILES Y MEDIO DIA LOS SABADOS
sueldoSemanal = sueldoDiario * CANTIDAD_JORNADAS_TRABAJADAS; //porque trabaja de lunes a viernes, y medio dia los sabados
        
        System.out.println("El sueldo que ganas semanalmente es de: " + sueldoSemanal + "$");
        
    }
    
}
