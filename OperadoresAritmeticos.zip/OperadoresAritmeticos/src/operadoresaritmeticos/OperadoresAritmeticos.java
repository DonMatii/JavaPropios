/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operadoresaritmeticos;

import java.util.Scanner;

/**
 * @fecha 08/10/2024
 * @author DonMatii
 */
public class OperadoresAritmeticos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        System.out.println("Vamos a aplicar matematicas!");

        int suma = 2 + 8;
        int resta = 10 - 2;
        int multiplicacion = 4 * 2;
        int division = 16 / 2;
        int a = 12354;
        int b = 2213;
        int modulo = a % b;
        int porcentaje = 100 * 2 / 20;
        int elevado = (int) Math.pow(4, 2);

        System.out.println("\n La Suma de 2+8 es: " + suma);
        System.out.println("La Resta de 10-2 es: " + resta);
        System.out.println("La Multiplicacion de 4*2 es: " + multiplicacion);
        System.out.println("La Division de 16/2 es: " + division);
        System.out.println("El Modulo de 12354/2213 es: " + modulo);
        System.out.println("El Porcentaje de 16&2 es: " + porcentaje);
        System.out.println("La elevaci�n cuadr�tica de 4^2 es: " + elevado);

        System.out.println("\n Ver cuando un  numero es Par o Impar con Scanner");

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingresa el primer numero: ");
        int Numero;
        Numero = sc.nextInt();

        if (Numero % 2 == 0) {
            System.out.println("Ingresaste el numero: " + Numero + " Es efectivamente un numero par!");
        } else {
            System.out.println("Ingresaste el n�mero: " + Numero + " No es un numero par :( ");
        }

    }

}
